<?php
require __DIR__ . '/../pix-config.php';
